﻿$(document).ready(function () {
    $("#activeMenu li").click(function () {
        $(this).addClass("active");
    });

});