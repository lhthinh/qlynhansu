﻿$(document).ready(function () {
    $("#table-taikhoan").DataTable();
});
